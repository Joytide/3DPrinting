                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3034224
Creality Ender 3 Cable Holder by Bleifuss23 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a simple and effective cabel holder for the Creality Ender 3. I designed this so it can be screwd directly on to the Extruder (it works with the original plastic one and the red aluminium upgrade part). As you can see the holder has a slight angle so that the cable hasn't bend as sharp.

You need to use a longer screw then the original one. Unfortunatly I didn't measure the one I used, because it is an left over from an old project. 

The use of a cable tie is optional but has a neat look to it. I used one of the provided ones.


Das ist ein simpler und effektiver Kabelhalter für den Creality Ender 3. Ich habe ihn so entworfen damit er direkt an den Extruder angeschraubt werden kann ( er funktioniert am originalen Plaste Teil sowie an dem Upgrade Alu Extruder). Der Halter ist soweit abgewinkelt damit das Kabel schön geführt werden kann.

Um in festschrauben zu können muss eine längere Schraube verwendet werden. Ich hab aber leider die Länge nicht gemessen weil die noch von einem anderen Projekt über war und gerade gepasset hat.

Der Kabelbinder ist nicht wirklich notwendig, dient mehr als Verliersicherung falls man mal das Kabel losschrauben sollte


# Print Settings

Printer Brand: Creality
Printer: Ender 3
Rafts: No
Supports: Yes
Resolution: 0,1
Infill: 100%
Filament_brand: Janbex Line 2
Filament_color: Orange
Filament_material: PLA

Notes: 
It isn't necessary to use a resolution of 0,1 mm, 0,2mm works just fine.